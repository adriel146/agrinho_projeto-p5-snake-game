function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}

let gridWidth = 30;
let gridHeight = 30;

let gameStarted = false;

let startingSegments = 5;

let xStart = 0;
let yStart = 15;

let startDirection = 'right';

let direction = startDirection;

let segments = [];

let score = 0;
let highScore;

let fruit;

function setup() {
  createCanvas(600, 600);

  frameRate(10);

  textAlign(CENTER, CENTER);
  textSize(2);

  highScore = getItem('high score');

  describe(
    'A reproduction of the arcade game Snake, in which a snake, represented by a black line on a #FFEB3B background, is controlled by the arrow keys. Users move the snake toward a fruit, represented by a red dot, but the snake must not hit the sides of the window or itself.'
  );
}

function draw() {
  background("#FFED4A");

  scale(width / gridWidth, height / gridHeight);
  if (gameStarted === false) {
    showStartScreen();
  } else {
  
    translate(0.5, 0.5);
    showFruit();
    showSegments();
    updateSegments();
    checkForCollision();
    checkForFruit();
  }
}

function showStartScreen() {
  noStroke();
  fill("#9E9E9E");
  rect(2, gridHeight / 2 - 5, gridWidth - 4, 10, 2);
  fill("black");
  text(
    'Clique para jogar.\nUse as setas para se mover.',
    gridWidth / 2,
    gridHeight / 2
  );
  noLoop();
}

function mousePressed() {
  if (gameStarted === false) {
    startGame();
  }
}

function startGame() {
  updateFruitCoordinates();

  segments = [];

  for (let x = xStart; x < xStart + startingSegments; x += 1) {
    let segmentPosition = createVector(x, yStart);

    segments.unshift(segmentPosition);
  }

  direction = startDirection;
  score = 0;
  gameStarted = true;
  loop();
}

function showFruit() {
  stroke("red");
  point(fruit.x, fruit.y);
}

function showSegments() {
  noFill();
  stroke(0, 0, 64);
  beginShape();
  for (let segment of segments) {
    vertex(segment.x, segment.y);
  }
  endShape();
}

function updateSegments() {
  segments.pop();

  let head = segments[0].copy();

  segments.unshift(head);

  switch (direction) {
    case 'right':
      head.x = head.x + 1;
      break;
    case 'up':
      head.y = head.y - 1;
      break;
    case 'left':
      head.x = head.x - 1;
      break;
    case 'down':
      head.y = head.y + 1;
      break;
  }
}

function checkForCollision() {
  let head = segments[0];

  if (
    head.x >= gridWidth ||
   
    head.x < 0 ||
    head.y >= gridHeight ||
    head.y < 0 ||
    selfColliding() === true
  ) {
    gameOver();
  }
}

function gameOver() {
  noStroke();
  fill("#9E9E9E");
  rect(1, gridHeight / 2 - 5, gridWidth - 2, 10, 2);
  fill("black");

  highScore = max(score, highScore);

  storeItem('high score', highScore);
  text(
    `Fim de jogo!
Sua pontuação: ${score}
Pontuação máxima: ${highScore}
Clique para jogar novamente.`,
    gridWidth / 2,
    gridHeight / 2
  );
  gameStarted = false;
  noLoop();
}

function selfColliding() {
  let head = segments[0];

  let segmentsAfterHead = segments.slice(1);

  for (let segment of segmentsAfterHead) {
    if (segment.equals(head) === true) {
      return true;
    }
  }
  return false;
}

function checkForFruit() {
  let head = segments[0];

  if (head.equals(fruit) === true) {
    score = score + 1;

    let tail = segments[segments.length - 1];
    let newSegment = tail.copy();

    segments.push(newSegment);

    updateFruitCoordinates();
  }
}

function updateFruitCoordinates() {
  let x = floor(random(gridWidth));
  let y = floor(random(gridHeight));
  fruit = createVector(x, y);
}

function keyPressed() {
  switch (keyCode) {
    case LEFT_ARROW:
      if (direction !== 'right') {
        direction = 'left';
      }
      break;
    case RIGHT_ARROW:
      if (direction !== 'left') {
        direction = 'right';
      }
      break;
    case UP_ARROW:
      if (direction !== 'down') {
        direction = 'up';
      }
      break;
    case DOWN_ARROW:
      if (direction !== 'up') {
        direction = 'down';
      }
      break;
  }
}